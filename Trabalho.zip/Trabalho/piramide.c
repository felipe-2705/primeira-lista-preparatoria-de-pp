#include<stdio.h>
#include<stdlib.h>
/*
Exercio P9 - piramide
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/
int main(){
    int l,i=0,h,j,k=1,a;
    printf("Digite o valor da altura da piramide: ");
    scanf("%d",&j);
    do{
            if(j>=10){
                if(k<10){
                a=(j-9);
                while(a>=1){printf(" ");--a;}
            }
           if(k>=10){
           a=(j-k);
            while(a>=1){printf(" ");--a;}
            }
            }

    l=j-k;
    do{
            if(l!=0)printf("   ");
    --l;
    }while(l>=0);
    while(i<k){printf("%d  ",i+1);++i;}
    while(i>1){printf("%d  ",i-1);--i;}
    printf("\n");
    ++k;
    i=0;
    }while(k<=j);
    return 0;
}
