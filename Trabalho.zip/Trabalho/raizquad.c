#include<stdio.h>
#include<stdlib.h>

/*
Exercio P3 - raizquad
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/

int main()
{
    int i=0;
    double valor,maior, menor=1,soma;
    do
    {
        printf("Digite um numero: ");
        scanf("%lf",&valor);
    }
    while(valor<0);
    maior=valor;
    soma=valor/2;
    do
    {
        if((soma*soma)>valor)
        {
            maior=soma;
            soma=(soma-(maior-menor)/2);
        }
        else
        {
            if((soma*soma)<valor)
            {
                menor=soma;
                soma=(soma+(maior-menor)/2);
            }
            else {}
        }
        ++i;
        if (i>=10000) break;
    }
    while (((soma*soma-valor)>0.0000001)||((soma*soma-valor)<-0.0000001));
    printf("A raiz quadrada aproximada eh %lf\n",soma);
    return 0;
}
