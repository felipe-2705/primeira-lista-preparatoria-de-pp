#include<stdio.h>
#include<stdlib.h>
#include<math.h>
/*
Exercio P8 - raiz_dezena
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/
int main(){
    int i=1000;
    printf("Os numeros raiz dezena de 1000 a 9999\n");
    do{
    if (sqrt(i)==((i/100)+i%100)) printf("%d\n",i);
    ++i;
    }while(i<=9999);
    return 0;
}
