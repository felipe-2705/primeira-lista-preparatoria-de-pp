#include<stdio.h>
#include<stdlib.h>

/*
Exercio P1 - Salario
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/
int main()
{
    char nome[50];
    int anos,anostrab,i=0;
    float salario=90000.00;
    printf("Seu nome: ");
    scanf("%[^\n]s",&nome);
    fflush(stdin);
    printf("Quantos anos trabalhados: ");
    scanf("%d",&anos);
    anostrab=anos;
    while(anos>1)
    {
        ++i;
        salario = salario*1.08;
        if (i==4)
        {
            salario = salario*1.04;
            i=0;
        }
        --anos;
    }
    if(salario>150000) salario=150000;
    printf("%s por %d anos. Salario atual: R$ %.2f / ano\n",nome,anostrab,salario);
    return 0;
}
