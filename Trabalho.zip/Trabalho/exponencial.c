#include<stdio.h>
#include<stdlib.h>

/*
Exercio P13 - expoente
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/
int main()
{
    int termo=0,i=1;
    double soma=1,x,xinicial,fatorial=1;
    printf("Digite o o valor do expoente de e: ");
    scanf("%lf",&x);
    xinicial=x;
    do
    {
        fatorial=(fatorial*(termo+i));
        if (termo!=0)x=x*xinicial;
        soma+=x/fatorial;
        ++termo;
    }
    while ((x/fatorial)>0.0000001);
    printf("A soma eh %.7lf",soma);
    return 0;

}
