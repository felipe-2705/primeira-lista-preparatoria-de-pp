#include <stdio.h>

/*
Exercio P7 - eh_semente
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/

int main ()
{
    int x,x1,x2,y,semente=1;
    printf("Descubra se um numero eh semente de outro.\n");

    printf("Digite o primeiro numero (positivo): ");
    scanf("%d",&x);
    printf("Digite o segundo  numero (positivo): ");
    scanf("%d",&y);
//verifica�ao dos numeros digitados
    if (x<0)
    {
        do
        {
            printf("Erro... digite dois numeros positivos.\n");
            printf("Digite o primeiro numero novamente: \n");
            scanf("%d",&x);
        }
        while(x<0);
    }
    if (y<0)
    {
        do
        {
            printf("Erro... digite dois numeros positivos.\n");
            printf("Digite o segundo  numero novamente: \n");
            scanf("%d",&y);
        }
        while (y<0);
    }
    x1=x;
    do
    {
        x2=x1%10;   // x2 acumular� o valor dos algorismos individuais de x
        x1=x1/10;    // x1 acumular� o valor restante sem o ultimo algorismo
        semente=semente*x2; //semente acumular� o resultado do produto dos algorismos de x .

    }
    while (x1>=1);
    semente = semente*x; // multiplicamos o produto dos algorismos pelo numero x original.
              if (semente == y ){printf("O numero %d eh semente do numero %d",x,y);}
              else printf("O numero %d nao eh semente do numero %d",x,y);
    return 0 ;
}
