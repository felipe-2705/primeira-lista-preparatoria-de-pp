#include<stdio.h>
/*
Exercio P18 - triangulodFloyd
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/
int main()
{
    int m,k=0,nlinhas,i=0,l=0,j=0,numero=1,soma=0;
    printf("Digite um numero inteiro positivo: ");
    scanf("%d",&nlinhas);
    m=nlinhas;
    for (l=0; l<m; m-=1)
    {
        for(k=m; k>=1; k--)
        {
            soma+=1;
        }
    }
    for (i=0; i<=nlinhas; i++)
    {
        for (j=0; j<l; j++)
        {
            if(soma>=100)
            {
                (numero<10)? printf("00"):numero<100?printf("0"):0;
            }
            else
            {
                soma>=10?numero<10? printf("0"):0:0;
            }
            printf("%d ",numero);
            ++numero;
        }
        printf("\n");
        ++l;
    }
    return 0;
}
