#include<stdio.h>
#include<stdlib.h>
/*
Exercio P16 - pi
Grupo :
    Thaynara
    Felipe
    Bianca
    Tarcisio
    Lucas
*/
int main(){
    int operador=0,i=3;
    double soma=1,pi;
    do{
    if (operador==0){
            soma-=(1.0/i);
            i+=2;
            operador=1;
    }
    else {soma+=(1.0/i);
    i+=2;
    operador=0;}
    }while((1.0/i)>0.000001);
    pi=soma*4;
    printf("%.5lf",pi);
    return 0;
}
